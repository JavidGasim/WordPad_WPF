﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WordPad_WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void open_btn_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "(*.txt)|*.txt|(*.*)|*.*";

            if (openFileDialog.ShowDialog() == true)
            {
                string filePath = openFileDialog.FileName;
                textBox1.Clear();
                textBox1.Text = filePath;

                string text = File.ReadAllText(filePath);

                richTextbox1.SelectAll();
                richTextbox1.Cut();
                richTextbox1.AppendText(text);
            }
        }

        private void save_btn_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "(*.txt)|*.txt|(*.*)|*.*";

            if (saveFileDialog.ShowDialog() == true)
            {
                string filePath = saveFileDialog.FileName;
                StreamWriter writer = new StreamWriter(filePath);
                richTextbox1.SelectAll();
                richTextbox1.Copy();
                string txt = Clipboard.GetText();
                writer.WriteLine(txt);
                writer.Close();
            }
        }

        private void cut_btn_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            TextRange selected = richTextbox1.Selection;

            if (selected != null && !selected.IsEmpty)
            {
                Clipboard.SetText(selected.Text);

                richTextbox1.Selection.Text = string.Empty;
            }

        }

        private void copy_btn_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            TextRange selected = richTextbox1.Selection;

            if (selected != null && !selected.IsEmpty)
            {
                Clipboard.SetText(selected.Text);
            }
        }

        private void paste_btn_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            string clipboardText = Clipboard.GetText();

            if (!string.IsNullOrEmpty(clipboardText))
            {
                TextRange selectedText = richTextbox1.Selection;
                TextPointer start = richTextbox1.CaretPosition;
                TextPointer end = start.GetPositionAtOffset(clipboardText.Length);

                selectedText.Text = string.Empty;
                selectedText.Text = clipboardText;
            }
        }

        private void select_all_btn_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            richTextbox1.SelectAll();
        }
    }
}